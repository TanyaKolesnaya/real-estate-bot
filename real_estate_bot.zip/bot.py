
import requests
import time
from telegram import Bot

# ==== НАСТРОЙКИ ====
TOKEN = '8120836282:AAE6nCrHCJmVBqJC7qDIopVycnl8G388_cY'
CHAT_ID = 574987631
CHECK_INTERVAL = 600  # секунд между проверками (10 минут)

bot = Bot(token=TOKEN)

# Храним ID уже отправленных объявлений
sent_ids = set()

# ========== KUFaR PARSER ==========
def fetch_kufar_ads():
    url = "https://api.kufar.by/search-api/v1/search/rendered-paginated"
    params = {
        "size": 30,
        "category": "1010",  # Недвижимость -> Квартиры
        "operation": "sell",
        "city": "Минск",
        "price[max]": "75000",
        "roomQuantity": ["2", "3"],
        "lang": "ru"
    }

    headers = {"User-Agent": "Mozilla/5.0"}
    ads = []

    response = requests.get(url, params=params, headers=headers)
    if response.ok:
        data = response.json()
        for ad in data.get("ads", []):
            ad_id = ad["ad_id"]
            if ad_id not in sent_ids:
                title = ad.get("subject")
                price = ad.get("price_usd", {}).get("converted", {}).get("USD", "")
                link = f"https://www.kufar.by/item/{ad_id}"
                ads.append((ad_id, f"Kufar: {title}\nЦена: ${price}\n{link}"))
    return ads

# ========== REALT PARSER ==========
def fetch_realt_ads():
    url = "https://realt.by/sale/flats/"
    ads = []

    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)

    if response.ok:
        html = response.text
        links = set()
        for line in html.splitlines():
            if '/sale/flats/object/' in line:
                start = line.find('/sale/flats/object/')
                end = line.find('"', start)
                link = line[start:end]
                full_link = f"https://realt.by{link}"
                if full_link not in sent_ids:
                    ads.append((full_link, f"Realt: Новая квартира\n{full_link}"))
    return ads

# ========== MAIN LOOP ==========
def main():
    print("Бот запущен. Ожидаем новые объявления...")

    while True:
        new_ads = []

        kufar = fetch_kufar_ads()
        realt = fetch_realt_ads()

        for ad_id, text in kufar:
            if ad_id not in sent_ids:
                new_ads.append(text)
                sent_ids.add(ad_id)

        for link, text in realt:
            if link not in sent_ids:
                new_ads.append(text)
                sent_ids.add(link)

        for ad_text in new_ads:
            bot.send_message(chat_id=CHAT_ID, text=ad_text)

        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()
